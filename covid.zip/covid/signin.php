<html>
    <head>
        <title>Signup form</title> 
        <link rel="stylesheet" type="text/css" href="login.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
include 'connect.php';
?>  
<style >
body {
    background-image: url("image1.jpg ");
      background-size:cover;
      background-repeat: no-repeat;
 } 

</style>  </head>
    <body>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <div id="login-box">
            <div class="left-box">
                <h1>Sign In</h1>
          
                <input type="text" name="email" placeholder="Email"/>
                <input type="password" name="password" placeholder="Password"/>

               

                <input type="submit" name="signIn-button" value="Login">
                
            </form>
           
</div>

        <div class="button">
            <a href="home.html">Back</a>
        </div>

        <?php
if (isset($_POST['email']) and isset($_POST['password']) ){
    
// Assigning POST values to variables.
$username = $_POST['email'];
$password = $_POST['password'];

$query = "SELECT * FROM `ouser` WHERE oemail='$username' and oupass='$password'";
 
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);

if ($count == 1){
    header("location: 7th.html");

}else{
echo "Invalid Login Credentials";
//echo "Invalid Login Credentials";
}
    



}

?>
            
    </body>
</html>